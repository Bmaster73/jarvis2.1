# Jarvis-ChatBot

Hello my name is Sergei and i have a youtube channel called techset Studios, i made a few tutorial on a jarvis chat bot wich was text based and not an AI, if anyone would like to edit this code and improve on it that is fine, i'm not doing anything with it now, have fun!

